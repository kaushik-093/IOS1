//
//  ViewController.swift
//  manavarthi_RestaurantApp
//
//  Created by Manavarthi,Sanjay Krishna on 4/26/22.
//

import UIKit

class Restdetails{
    var restaurantName : String?
    
    
    init(resName: String){
        self.restaurantName = resName;
        
    }
    
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableViewOutlet.dequeueReusableCell(withIdentifier: "reusableCell", for: indexPath)
        cell.textLabel?.text = restArr[indexPath.row].restaurantName
        return cell
    }

    var restArr = [Restdetails]()
    
    @IBOutlet weak var tableViewOutlet: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableViewOutlet.delegate = self
        tableViewOutlet.dataSource = self
        
        let res1 = Restdetails(resName: "AG")
        restArr.append(res1)
        let res2 = Restdetails(resName: "Applebees")
        restArr.append(res2)
        let res3 = Restdetails(resName: "pizzaRanch")
        restArr.append(res3)
        let res4 = Restdetails(resName: "SimplySiam")
        restArr.append(res4)
        let res5 = Restdetails(resName: "elMaguey")
        restArr.append(res5)
        let res6 = Restdetails(resName: "A&G")
        restArr.append(res6)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "resultSegue"{
            let destination = segue.destination as! RestaurantDetailsViewController
            destination.Restdetails = restArr[(tableViewOutlet.indexPathForSelectedRow?.row)!]
        }
    
    }


}


